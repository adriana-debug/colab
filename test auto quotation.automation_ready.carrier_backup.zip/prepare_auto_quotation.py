from __future__ import annotations

from copy import copy
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter


WORKBOOK_PATH = Path("test auto quotation.xlsx")
OUTPUT_PATH = Path("test auto quotation.automation_ready.xlsx")

SOURCE_SHEET = "ship_orders"
TEMPLATE_SHEET = "ship_order_template"
CONTROL_SHEET = "template_control"
MAPPING_SHEET = "template_mapping"

INVOICING_BLOCK = (
    "American Range Walls LLC\n"
    "6600 SW Church Rd\n"
    "Augusta, KS 67010\n"
    "Contact: Jake Williams\n"
    "Phone: +1-712-660-0447\n"
    "Email: invoice@americanrangewalls.com"
)

ORDERED_COLUMNS = [
    "Order Number",
    "Associated ARW Order Number",
    "Order Date",
    "Pickup Date",
    "Estimated Delivery Date",
    "Ship From Company Name",
    "Ship From Address Line 1",
    "Ship From Address Line 2",
    "Ship From City",
    "Ship From State",
    "Ship From Zip Code",
    "Ship From Country",
    "Ship From Contact",
    "Ship From Phone",
    "Ship From Email",
    "Ship From Hours",
    "Ship From Instructions",
    "Pickup Appointment Required",
    "Pickup Dock",
    "Ship To Company Name",
    "Ship To Address Line 1",
    "Ship To Address Line 2",
    "Ship To City",
    "Ship To State",
    "Ship To Zip Code",
    "Ship To Country",
    "Ship To Contact",
    "Ship To Phone",
    "Ship To Email",
    "Ship To Delivery Notes",
    "Delivery Appointment Required",
    "Delivery Dock",
    "Liftgate Required",
    "Carrier Broker",
    "Carrier Name",
    "Carrier Contact",
    "Carrier Phone",
    "Carrier Email",
    "Load Type",
    "International",
    "Item 1 Description",
    "Item 1 Quantity",
    "Item 1 Unit Price",
    "Item 1 Total",
    "Item 2 Description",
    "Item 2 Quantity",
    "Item 2 Unit Price",
    "Item 2 Total",
    "Item 3 Description",
    "Item 3 Quantity",
    "Item 3 Unit Price",
    "Item 3 Total",
    "Subtotal",
    "Tax",
    "Shipping",
    "Grand Total",
    "Template Ship From (A5)",
    "Template Carrier Information (I5)",
    "Template Ship To (A7)",
    "Template Care Of & Invoicing (I7)",
    "Template Special Instructions (A8)",
    "Template Pickup/Delivery Dates (I8)",
    "Template Cargo Description (A12)",
    "Template Cargo Total Units (G12)",
    "Template Cargo Total Pallet Count (H12)",
    "Template Cargo Total Weight (I12)",
    "Template Cargo Notes (J12)",
    "Data Completeness Notes",
]


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return format_short_date(value)
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def clean_zip(value: Any) -> str:
    text = clean_text(value)
    if text.endswith(".0"):
        text = text[:-2]
    return text


def yes_no_unknown(value: Any, default: str = "Unknown") -> str:
    text = clean_text(value).lower()
    if text in {"yes", "y", "true", "1"}:
        return "Yes"
    if text in {"no", "n", "false", "0"}:
        return "No"
    return default


def default_pickup_date(order_date: Any) -> Any:
    if isinstance(order_date, datetime):
        return order_date + timedelta(days=1)
    return None


def default_delivery_date(order_date: Any) -> Any:
    if isinstance(order_date, datetime):
        return order_date + timedelta(days=4)
    return None


def format_short_date(value: datetime) -> str:
    return f"{value.month}/{value.day}/{value.year % 100:02d}"


def build_address_block(
    company: str,
    address1: str,
    address2: str,
    city: str,
    state: str,
    postal_code: str,
    country: str,
    contact_label: str,
    contact_name: str,
    phone: str,
    email: str,
    extra_lines: list[str] | None = None,
) -> str:
    lines = [clean_text(company)]
    if clean_text(address1):
        lines.append(clean_text(address1))
    if clean_text(address2):
        lines.append(clean_text(address2))

    city_text = clean_text(city)
    state_text = clean_text(state)
    postal_text = clean_text(postal_code)
    city_state_zip = " ".join(
        part for part in [f"{city_text}," if city_text else "", state_text, postal_text] if part
    ).strip()
    if clean_text(country):
        city_state_zip = f"{city_state_zip} {clean_text(country)}".strip()
    if city_state_zip:
        city_state_zip = city_state_zip.replace(" ,", ",")
        lines.append(city_state_zip)

    contact_bits = [bit for bit in [clean_text(contact_name), clean_text(phone), clean_text(email)] if bit]
    if contact_bits:
        lines.append(f"{contact_label}: {' / '.join(contact_bits)}")

    if extra_lines:
        lines.extend(line for line in extra_lines if clean_text(line))

    return "\n".join(line for line in lines if clean_text(line))


def build_carrier_block(record: dict[str, Any]) -> str:
    lines = [
        f"Broker: {clean_text(record['Carrier Broker']) or 'TBD'}",
        f"Broker Contact: {clean_text(record['Carrier Contact']) or 'TBD'}",
        f"Carrier: {clean_text(record['Carrier Name']) or clean_text(record['Carrier Broker']) or 'TBD'}",
        f"Carrier Phone: {clean_text(record['Carrier Phone']) or 'TBD'}",
        f"Carrier Email: {clean_text(record['Carrier Email']) or 'TBD'}",
        f"Pickup Appointment Required: {clean_text(record['Pickup Appointment Required']) or 'Unknown'}",
        f"Delivery Appointment Required: {clean_text(record['Delivery Appointment Required']) or 'Unknown'}",
        f"Load Type: {clean_text(record['Load Type']) or 'TBD'}",
        f"International: {clean_text(record['International']) or 'No'}",
        f"Pickup Dock: {clean_text(record['Pickup Dock']) or 'Unknown'}",
        f"Delivery Dock: {clean_text(record['Delivery Dock']) or 'Unknown'}",
    ]
    if clean_text(record["Liftgate Required"]):
        lines.append(f"Liftgate Required: {clean_text(record['Liftgate Required'])}")
    return "\n".join(lines)


def build_special_instructions(record: dict[str, Any]) -> str:
    bullets = []
    if clean_text(record["Ship From Instructions"]):
        bullets.append(clean_text(record["Ship From Instructions"]))
    if clean_text(record["Ship To Delivery Notes"]):
        bullets.append(clean_text(record["Ship To Delivery Notes"]))
    bullets.append("Provide Pro # / tracking information to invoice@americanrangewalls.com when available.")
    text = "\n".join(f"- {item}" for item in bullets if clean_text(item))
    return f"Special Instructions:\n{text}" if text else "Special Instructions:"


def build_pickup_delivery_block(record: dict[str, Any]) -> str:
    pickup = record["Pickup Date"]
    delivery = record["Estimated Delivery Date"]
    pickup_text = format_short_date(pickup) if isinstance(pickup, datetime) else "TBD"
    delivery_text = format_short_date(delivery) if isinstance(delivery, datetime) else "TBD"
    return f"Pickup Date: {pickup_text}\n\nEst. Delivery Date: {delivery_text}"


def sum_item_quantities(record: dict[str, Any]) -> float:
    total = 0.0
    for idx in range(1, 4):
        value = record.get(f"Item {idx} Quantity")
        if isinstance(value, (int, float)):
            total += float(value)
    return total


def joined_item_descriptions(record: dict[str, Any]) -> str:
    descriptions = []
    for idx in range(1, 4):
        text = clean_text(record.get(f"Item {idx} Description"))
        if text:
            descriptions.append(text)
    return "; ".join(descriptions)


def template_lookup_formula(lookup_col: str, return_col: str) -> str:
    control_ref = f"'{CONTROL_SHEET}'!$B$1"
    return (
        f'=IFERROR(INDEX(\'{SOURCE_SHEET}\'!${return_col}:${return_col},'
        f'MATCH({control_ref},\'{SOURCE_SHEET}\'!${lookup_col}:${lookup_col},0)),"")'
    )


def recreate_sheet(wb, sheet_name: str):
    if sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        idx = wb.sheetnames.index(sheet_name)
        wb.remove(ws)
        return wb.create_sheet(title=sheet_name, index=idx)
    return wb.create_sheet(title=sheet_name)


def main() -> None:
    wb = load_workbook(WORKBOOK_PATH)
    source_ws = wb[SOURCE_SHEET]
    template_ws = wb[TEMPLATE_SHEET]

    original_headers = [source_ws.cell(1, col).value for col in range(1, source_ws.max_column + 1)]
    source_rows = []
    for row_idx in range(2, source_ws.max_row + 1):
        row_values = {header: source_ws.cell(row_idx, col_idx).value for col_idx, header in enumerate(original_headers, start=1)}
        source_rows.append(row_values)

    normalized_rows: list[dict[str, Any]] = []
    for row in source_rows:
        record = {column: row.get(column) for column in ORDERED_COLUMNS}

        record["Pickup Date"] = row.get("Pickup Date") or default_pickup_date(row.get("Order Date"))
        record["Estimated Delivery Date"] = row.get("Estimated Delivery Date") or default_delivery_date(row.get("Order Date"))

        record["Ship From Address Line 2"] = row.get("Ship From Address Line 2") or ""
        record["Ship From Country"] = row.get("Ship From Country") or "USA"
        record["Ship From Email"] = row.get("Ship From Email") or ""
        record["Ship From Hours"] = row.get("Ship From Hours") or ""
        record["Pickup Appointment Required"] = row.get("Pickup Appointment Required") or "Yes"
        record["Pickup Dock"] = row.get("Pickup Dock") or "Unknown"

        record["Ship To Address Line 2"] = row.get("Ship To Address Line 2") or ""
        record["Ship To Country"] = row.get("Ship To Country") or "USA"
        record["Ship To Email"] = row.get("Ship To Email") or ""
        record["Ship To Delivery Notes"] = row.get("Ship To Delivery Notes") or ""
        record["Delivery Appointment Required"] = row.get("Delivery Appointment Required") or "Unknown"
        record["Delivery Dock"] = row.get("Delivery Dock") or "Unknown"
        record["Liftgate Required"] = row.get("Liftgate Required") or "Unknown"

        record["Carrier Name"] = row.get("Carrier Name") or row.get("Carrier Broker") or ""
        record["Carrier Email"] = row.get("Carrier Email") or ""
        record["Load Type"] = row.get("Load Type") or "LTL"
        record["International"] = row.get("International") or "No"

        ship_from_block = build_address_block(
            company=record["Ship From Company Name"],
            address1=record["Ship From Address Line 1"],
            address2=record["Ship From Address Line 2"],
            city=record["Ship From City"],
            state=record["Ship From State"],
            postal_code=clean_zip(record["Ship From Zip Code"]),
            country=record["Ship From Country"],
            contact_label="Contact",
            contact_name=record["Ship From Contact"],
            phone=record["Ship From Phone"],
            email=record["Ship From Email"],
            extra_lines=[record["Ship From Hours"], record["Ship From Instructions"]],
        )
        ship_to_extra = []
        if clean_text(record["Liftgate Required"]).lower() == "yes":
            ship_to_extra.append("Liftgate required at destination.")
        if clean_text(record["Ship To Delivery Notes"]):
            ship_to_extra.append(clean_text(record["Ship To Delivery Notes"]))
        ship_to_block = build_address_block(
            company=record["Ship To Company Name"],
            address1=record["Ship To Address Line 1"],
            address2=record["Ship To Address Line 2"],
            city=record["Ship To City"],
            state=record["Ship To State"],
            postal_code=clean_zip(record["Ship To Zip Code"]),
            country=record["Ship To Country"],
            contact_label="Delivery Contact",
            contact_name=record["Ship To Contact"],
            phone=record["Ship To Phone"],
            email=record["Ship To Email"],
            extra_lines=ship_to_extra,
        )
        cargo_description = joined_item_descriptions(record)
        cargo_units = sum_item_quantities(record)

        missing_notes = []
        for required_col in [
            "Ship From Email",
            "Ship To Email",
            "Pickup Date",
            "Estimated Delivery Date",
            "Template Cargo Total Pallet Count (H12)",
            "Template Cargo Total Weight (I12)",
        ]:
            if not clean_text(record.get(required_col)):
                missing_notes.append(required_col)

        record["Template Ship From (A5)"] = ship_from_block
        record["Template Carrier Information (I5)"] = build_carrier_block(record)
        record["Template Ship To (A7)"] = ship_to_block
        record["Template Care Of & Invoicing (I7)"] = INVOICING_BLOCK
        record["Template Special Instructions (A8)"] = build_special_instructions(record)
        record["Template Pickup/Delivery Dates (I8)"] = build_pickup_delivery_block(record)
        record["Template Cargo Description (A12)"] = cargo_description
        record["Template Cargo Total Units (G12)"] = cargo_units
        record["Template Cargo Total Pallet Count (H12)"] = row.get("Template Cargo Total Pallet Count (H12)") or ""
        record["Template Cargo Total Weight (I12)"] = row.get("Template Cargo Total Weight (I12)") or ""
        record["Template Cargo Notes (J12)"] = f"{len([x for x in cargo_description.split('; ') if x])} line item(s)"
        record["Data Completeness Notes"] = ", ".join(missing_notes)
        normalized_rows.append(record)

    for col_idx, header in enumerate(ORDERED_COLUMNS, start=1):
        source_ws.cell(1, col_idx).value = header

    for row_idx, record in enumerate(normalized_rows, start=2):
        for col_idx, header in enumerate(ORDERED_COLUMNS, start=1):
            source_ws.cell(row_idx, col_idx).value = record.get(header)

    if source_ws.max_column > len(ORDERED_COLUMNS):
        for extra_col in range(len(ORDERED_COLUMNS) + 1, source_ws.max_column + 1):
            for row_idx in range(1, source_ws.max_row + 1):
                source_ws.cell(row_idx, extra_col).value = None

    header_lookup = {header: get_column_letter(idx) for idx, header in enumerate(ORDERED_COLUMNS, start=1)}

    control_ws = recreate_sheet(wb, CONTROL_SHEET)
    control_ws["A1"] = "Active Order Number"
    control_ws["B1"] = normalized_rows[0]["Order Number"] if normalized_rows else ""
    control_ws["A3"] = "Available Orders"
    for idx, record in enumerate(normalized_rows, start=4):
        control_ws.cell(idx, 1).value = record["Order Number"]
    control_ws.column_dimensions["A"].width = 24
    control_ws.column_dimensions["B"].width = 18

    mapping_ws = recreate_sheet(wb, MAPPING_SHEET)
    mapping_headers = ["Template Cell", "Purpose", "Source Column", "Status / Notes"]
    mapping_rows = [
        ("A2", "Ship order number label", "Order Number", "Concatenated into label"),
        ("L2", "Order date", "Order Date", "Direct date lookup"),
        ("A3", "Associated order number label", "Associated ARW Order Number", "Concatenated into label"),
        ("A5", "Ship from block", "Template Ship From (A5)", "Prepared multiline helper"),
        ("I5", "Carrier information block", "Template Carrier Information (I5)", "Prepared multiline helper"),
        ("A7", "Ship to block", "Template Ship To (A7)", "Prepared multiline helper"),
        ("I7", "Care of / invoicing block", "Template Care Of & Invoicing (I7)", "Static helper"),
        ("A8", "Special instructions", "Template Special Instructions (A8)", "Prepared multiline helper"),
        ("I8", "Pickup and estimated delivery dates", "Template Pickup/Delivery Dates (I8)", "Prepared multiline helper"),
        ("A12", "Cargo description", "Template Cargo Description (A12)", "Joined item descriptions"),
        ("G12", "Cargo total units", "Template Cargo Total Units (G12)", "Summed item quantities"),
        ("H12", "Cargo pallet count", "Template Cargo Total Pallet Count (H12)", "Blank until pallet data is supplied"),
        ("I12", "Cargo total weight", "Template Cargo Total Weight (I12)", "Blank until weight data is supplied"),
        ("J12", "Cargo notes", "Template Cargo Notes (J12)", "Derived helper"),
    ]
    for col_idx, header in enumerate(mapping_headers, start=1):
        cell = mapping_ws.cell(1, col_idx)
        cell.value = header
        cell.font = Font(bold=True)
    for row_idx, values in enumerate(mapping_rows, start=2):
        for col_idx, value in enumerate(values, start=1):
            mapping_ws.cell(row_idx, col_idx).value = value
    for column in ("A", "B", "C", "D"):
        mapping_ws.column_dimensions[column].width = 34

    lookup_col = header_lookup["Order Number"]
    template_ws["A2"] = f'="ARW Ship Order (SO) Number: "&{template_lookup_formula(lookup_col, header_lookup["Order Number"])[1:]}'
    template_ws["L2"] = template_lookup_formula(lookup_col, header_lookup["Order Date"])
    template_ws["A3"] = (
        f'="Associated ARW Order Number: "&'
        f'{template_lookup_formula(lookup_col, header_lookup["Associated ARW Order Number"])[1:]}'
    )
    template_ws["A5"] = template_lookup_formula(lookup_col, header_lookup["Template Ship From (A5)"])
    template_ws["I5"] = template_lookup_formula(lookup_col, header_lookup["Template Carrier Information (I5)"])
    template_ws["A7"] = template_lookup_formula(lookup_col, header_lookup["Template Ship To (A7)"])
    template_ws["I7"] = template_lookup_formula(lookup_col, header_lookup["Template Care Of & Invoicing (I7)"])
    template_ws["A8"] = template_lookup_formula(lookup_col, header_lookup["Template Special Instructions (A8)"])
    template_ws["I8"] = template_lookup_formula(lookup_col, header_lookup["Template Pickup/Delivery Dates (I8)"])
    template_ws["A12"] = template_lookup_formula(lookup_col, header_lookup["Template Cargo Description (A12)"])
    template_ws["G12"] = template_lookup_formula(lookup_col, header_lookup["Template Cargo Total Units (G12)"])
    template_ws["H12"] = template_lookup_formula(lookup_col, header_lookup["Template Cargo Total Pallet Count (H12)"])
    template_ws["I12"] = template_lookup_formula(lookup_col, header_lookup["Template Cargo Total Weight (I12)"])
    template_ws["J12"] = template_lookup_formula(lookup_col, header_lookup["Template Cargo Notes (J12)"])

    wb.save(OUTPUT_PATH)
    print(f"Wrote {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
