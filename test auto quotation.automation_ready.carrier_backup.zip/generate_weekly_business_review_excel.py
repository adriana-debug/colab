from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


def fill_range(ws, cell_range, fill):
    for row in ws[cell_range]:
        for cell in row:
            cell.fill = fill


def border_range(ws, cell_range, border):
    for row in ws[cell_range]:
        for cell in row:
            cell.border = border


def style_text(cell, value, *, font=None, fill=None, alignment=None, border=None):
    cell.value = value
    if font:
        cell.font = font
    if fill:
        cell.fill = fill
    if alignment:
        cell.alignment = alignment
    if border:
        cell.border = border


def merge_label(ws, start, end, value, *, font, fill, alignment, border=None):
    ws.merge_cells(f"{start}:{end}")
    style_text(ws[start], value, font=font, fill=fill, alignment=alignment, border=border)
    if border:
        border_range(ws, f"{start}:{end}", border)


def main():
    wb = Workbook()
    ws = wb.active
    ws.title = "Weekly Business Review"
    ws.sheet_view.showGridLines = False

    # Palette
    navy = "1F2F36"
    teal = "2F5361"
    gold = "B8902F"
    rust = "9B4527"
    green = "28753F"
    olive = "445A2A"
    red = "9B2424"
    light = "F4F6F8"
    white = "FFFFFF"
    gray = "D9E0E6"
    text = "1A2730"
    muted = "738494"

    fill_navy = PatternFill("solid", fgColor=navy)
    fill_teal = PatternFill("solid", fgColor=teal)
    fill_gold = PatternFill("solid", fgColor=gold)
    fill_rust = PatternFill("solid", fgColor=rust)
    fill_green = PatternFill("solid", fgColor=green)
    fill_olive = PatternFill("solid", fgColor=olive)
    fill_red = PatternFill("solid", fgColor=red)
    fill_light = PatternFill("solid", fgColor=light)
    fill_white = PatternFill("solid", fgColor=white)

    thin_gray = Side(style="thin", color=gray)
    med_navy = Side(style="medium", color=navy)
    border_thin = Border(left=thin_gray, right=thin_gray, top=thin_gray, bottom=thin_gray)
    border_panel = Border(left=med_navy, right=thin_gray, top=thin_gray, bottom=thin_gray)

    font_title = Font(name="Arial", size=16, bold=True, color=white)
    font_header = Font(name="Arial", size=10, bold=True, color=white)
    font_sub = Font(name="Arial", size=8, color=white)
    font_big = Font(name="Arial", size=18, bold=True, color=text)
    font_med = Font(name="Arial", size=11, bold=True, color=text)
    font_body = Font(name="Arial", size=10, color=text)
    font_muted = Font(name="Arial", size=9, color=muted)
    font_white_bold = Font(name="Arial", size=10, bold=True, color=white)
    font_small = Font(name="Arial", size=8, color=text)

    center = Alignment(horizontal="center", vertical="center")
    left = Alignment(horizontal="left", vertical="center")
    left_wrap = Alignment(horizontal="left", vertical="center", wrap_text=True)
    right = Alignment(horizontal="right", vertical="center")

    # Column widths
    widths = {
        "A": 2, "B": 14, "C": 14, "D": 14, "E": 14,
        "F": 2, "G": 18, "H": 18, "I": 18, "J": 18,
        "K": 2, "L": 15, "M": 15, "N": 15, "O": 15,
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width

    # Row heights
    for r in range(1, 34):
        ws.row_dimensions[r].height = 24
    ws.row_dimensions[1].height = 34
    ws.row_dimensions[2].height = 10
    ws.row_dimensions[4].height = 30
    for r in [10, 13, 16, 19, 22, 25, 28]:
        ws.row_dimensions[r].height = 28

    # Background
    fill_range(ws, "A1:O33", fill_light)

    # Top bar
    fill_range(ws, "A1:O2", fill_navy)
    merge_label(
        ws, "B1", "E1", "WEEKLY BUSINESS REVIEW",
        font=font_title, fill=fill_navy, alignment=left
    )
    merge_label(
        ws, "H1", "M1", "American Range Walls  ·  Order-to-Cash  ·  Week of March 9–13, 2026",
        font=font_sub, fill=fill_navy, alignment=right
    )
    merge_label(
        ws, "N1", "O1", "• ON TRACK",
        font=font_white_bold, fill=fill_green, alignment=center, border=border_thin
    )
    fill_range(ws, "A1:A2", fill_gold)

    # Left section
    merge_label(ws, "B4", "E4", "CRM ANALYSIS", font=font_header, fill=fill_navy, alignment=left, border=border_thin)
    fill_range(ws, "B4:B4", fill_gold)

    kpis = [
        ("B5:B7", "268", "Open Deals"),
        ("C5:C7", "$1.62M", "Pipeline"),
        ("D5:D7", "32", "New Contacts"),
        ("E5:E7", "67.9d", "Avg Deal Age"),
    ]
    for rng, value, label in kpis:
        fill_range(ws, rng, fill_white)
        border_range(ws, rng, border_thin)
        top = rng.split(":")[0]
        col = top[0]
        style_text(ws[f"{col}5"], value, font=font_big, alignment=center, fill=fill_white, border=border_thin)
        style_text(ws[f"{col}7"], label, font=font_muted, alignment=center, fill=fill_white, border=border_thin)

    left_items = [
        ("Woo × OnePage Cross-Ref", "99.2% matched", gold),
        ("Deal Value Analysis", "$1.62M pipeline", green),
        ("Order Value Segmentation", "3 tiers active", green),
        ("Pipeline Breakdown (Future)", "$47K at risk", gold),
        ("Deal Age Analysis", "412 deals > 30d", red),
        ("AOV (Looker Dashboard)", "$?? avg", green),
        ("Prospect Purge / Cleanup", "45 to archive", red),
    ]
    row = 8
    for label, value, accent in left_items:
        fill_range(ws, f"B{row}:E{row+1}", fill_white)
        border_range(ws, f"B{row}:E{row+1}", border_thin)
        style_text(ws[f"B{row}"], " ", fill=PatternFill("solid", fgColor=accent), border=border_thin)
        style_text(ws[f"B{row+1}"], label, font=font_body, alignment=left, fill=fill_white, border=border_thin)
        merge_label(ws, f"C{row+1}", f"E{row+1}", value, font=font_med, fill=fill_white, alignment=right, border=border_thin)
        row += 2

    merge_label(ws, "B22", "E22", "ORDER VALUE SEGMENTATION", font=font_header, fill=fill_teal, alignment=left, border=border_thin)
    fill_range(ws, "B22:B22", fill_gold)
    merge_label(ws, "B23", "C24", "<$1K  53.2%", font=font_white_bold, fill=fill_white, alignment=center, border=border_thin)
    merge_label(ws, "D23", "D24", "$1K–$5K  19.1%", font=font_white_bold, fill=fill_teal, alignment=center, border=border_thin)
    merge_label(ws, "E23", "E24", ">$5K  27.7%", font=font_white_bold, fill=fill_rust, alignment=center, border=border_thin)

    # Middle section
    merge_label(ws, "G4", "J4", "ORDER-TO-CASH CORE ACTIVITIES", font=font_header, fill=fill_teal, alignment=left, border=border_thin)
    fill_range(ws, "G4:G4", fill_gold)

    middle_blocks = [
        ("Order Management", "16 orders", navy, ["Order intake & validation", "ERP entry", "Pricing verification", "Credit check coord."]),
        ("Billing & Invoicing", "41 invoices", teal, ["Invoice creation & validation", "Invoice delivery", "Tax / compliance checks", "Billing corrections"]),
        ("Cash Application", "$94K posted", olive, ["Payment posting", "Unapplied cash", "Remittance recon", "Short payments"]),
        ("Collections", "25 inv. overdue", gold, ["Aging review", "Payment negotiations", "Customer follow-ups", "Escalation mgmt"]),
        ("Dispute Management", "0 open", red, ["Identify disputes", "Internal coordination", "Root cause analysis", "Resolution tracking"]),
        ("Reporting", "Live → Looker", navy, ["AR aging", "Collection KPIs", "DSO monitoring", "Operational KPIs"]),
    ]
    start_rows = [5, 9, 13, 17, 21, 25]
    for (title, tag, accent, bullets), start in zip(middle_blocks, start_rows):
        fill_range(ws, f"G{start}:J{start+3}", fill_white)
        border_range(ws, f"G{start}:J{start+3}", border_panel)
        fill_range(ws, f"G{start}:G{start+3}", PatternFill("solid", fgColor=accent))
        merge_label(ws, f"H{start}", f"I{start}", title, font=Font(name="Arial", size=11, bold=True, color=text), fill=fill_white, alignment=left, border=border_thin)
        style_text(ws[f"J{start}"], tag, font=font_white_bold, fill=PatternFill("solid", fgColor=accent), alignment=center, border=border_thin)
        style_text(ws[f"H{start+1}"], f"– {bullets[0]}", font=font_muted, alignment=left, fill=fill_white, border=border_thin)
        style_text(ws[f"H{start+2}"], f"– {bullets[1]}", font=font_muted, alignment=left, fill=fill_white, border=border_thin)
        style_text(ws[f"I{start+1}"], f"– {bullets[2]}", font=font_muted, alignment=left, fill=fill_white, border=border_thin)
        style_text(ws[f"I{start+2}"], f"– {bullets[3]}", font=font_muted, alignment=left, fill=fill_white, border=border_thin)

    # Right section
    merge_label(ws, "L4", "O4", "KPI SCORECARD", font=font_header, fill=fill_rust, alignment=left, border=border_thin)
    fill_range(ws, "L4:L4", fill_gold)

    score_rows = [
        ("Email Response SLA", "< 60 min", "60 min", green),
        ("Order Entry Accuracy", "99.5%", "99.8%", green),
        ("Quote Accuracy (+$25)", "100%", "100%", green),
        ("CRM Completeness", "> 95%", "49%", gold),
        ("First Contact Res.", "> 80%", "76%", gold),
        ("Checklist Completion", "100%", "94%", gold),
        ("AR Tracker Accuracy", "> 98%", "99.1%", green),
        ("Days Sales Outstanding", "< 45d", "25.5d", green),
        ("Invoice Dispute Rate", "< 2%", "0.0%", green),
    ]
    row = 5
    for label, target, actual, color in score_rows:
        fill_range(ws, f"L{row}:O{row+1}", fill_white)
        border_range(ws, f"L{row}:O{row+1}", border_thin)
        merge_label(ws, f"L{row}", f"M{row+1}", label, font=font_body, fill=fill_white, alignment=left, border=border_thin)
        merge_label(ws, f"N{row}", f"N{row+1}", target, font=font_muted, fill=fill_white, alignment=center, border=border_thin)
        merge_label(ws, f"O{row}", f"O{row+1}", actual, font=font_white_bold, fill=PatternFill("solid", fgColor=color), alignment=center, border=border_thin)
        row += 2

    merge_label(ws, "L23", "O23", "AR AGING SNAPSHOT", font=font_header, fill=fill_navy, alignment=left, border=border_thin)
    fill_range(ws, "L23:L23", fill_gold)
    aging = [
        ("$84,885.77", "64.3%", "Aged 1-30"),
        ("$39,449.37", "29.9%", "Aged 31-60"),
        ("$7,655.29", "5.8%", "Aged 61-90"),
        ("$0.00", "0.0%", "Aged > 91"),
    ]
    cols = ["L", "M", "N", "O"]
    for col, (amt, pct, label) in zip(cols, aging):
        style_text(ws[f"{col}25"], amt, font=font_med, alignment=center, fill=fill_white)
        style_text(ws[f"{col}26"], pct, font=font_body, alignment=center, fill=fill_white)
        style_text(ws[f"{col}27"], label, font=font_med, alignment=center, fill=fill_white)

    # Bottom ribbon
    fill_range(ws, "A31:O32", fill_navy)
    stages = [
        ("B31:C31", "Inquiry  ?"),
        ("D31:E31", "Quote Sent  ?"),
        ("F31:G31", "Order Confirmed  24"),
        ("H31:I31", "In Fulfillment  16"),
        ("J31:K31", "Shipped  79 +"),
        ("L31:M31", "Invoiced  210"),
        ("N31:O31", "Closed Won  210 + 24"),
    ]
    for rng, text_value in stages:
        merge_label(ws, rng.split(":")[0], rng.split(":")[1], text_value, font=font_white_bold, fill=fill_navy, alignment=center)
    for col in ["D", "F", "H", "J", "L", "N"]:
        fill_range(ws, f"{col}31:{col}31", fill_gold)

    merge_label(
        ws, "B32", "O32",
        "Confidential — Internal Use Only  ·  ARW Weekly Business Review  ·  March 2026",
        font=Font(name="Arial", size=8, color=muted), fill=fill_navy, alignment=center
    )

    ws.freeze_panes = "B5"
    wb.save("weekly_business_review_dashboard.xlsx")


if __name__ == "__main__":
    main()
