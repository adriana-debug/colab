# Google Apps Script: Export Quotation Template to PDF

This document explains how to export the `ship_order_template` sheet as a PDF from a Google Sheets file stored in Google Drive.

## Overview

The process is:

1. Set the active order number in `template_control!B1`.
2. Let the template recalculate.
3. Export the `ship_order_template` sheet as PDF.
4. Save the PDF into a Drive folder.

This works well when:

- `ship_orders` contains the source data
- `ship_order_template` is formula-driven
- `template_control!B1` controls which order is shown in the template

## Apps Script Code

```javascript
const TEMPLATE_SHEET = 'ship_order_template';
const CONTROL_SHEET = 'template_control';
const SOURCE_SHEET = 'ship_orders';
const PDF_FOLDER_ID = 'YOUR_FOLDER_ID';

function exportQuotationPdf(orderNumber) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const templateSheet = ss.getSheetByName(TEMPLATE_SHEET);
  const controlSheet = ss.getSheetByName(CONTROL_SHEET);
  const folder = DriveApp.getFolderById(PDF_FOLDER_ID);

  // Set the order number that drives the template
  controlSheet.getRange('B1').setValue(orderNumber);
  SpreadsheetApp.flush();
  Utilities.sleep(1500);

  const blob = exportSheetAsPdf_(
    ss.getId(),
    templateSheet.getSheetId(),
    `Quotation_${orderNumber}.pdf`
  );

  const file = folder.createFile(blob);
  return {
    orderNumber,
    fileId: file.getId(),
    url: file.getUrl(),
  };
}

function exportAllQuotations() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sourceSheet = ss.getSheetByName(SOURCE_SHEET);
  const values = sourceSheet.getDataRange().getValues();
  const headers = values[0];
  const orderCol = headers.indexOf('Order Number');

  if (orderCol === -1) {
    throw new Error('Order Number column not found.');
  }

  const results = [];
  for (let i = 1; i < values.length; i++) {
    const orderNumber = values[i][orderCol];
    if (!orderNumber) continue;
    results.push(exportQuotationPdf(orderNumber));
  }

  Logger.log(results);
  return results;
}

function exportSheetAsPdf_(spreadsheetId, sheetId, filename) {
  const url =
    `https://docs.google.com/spreadsheets/d/${spreadsheetId}/export` +
    `?format=pdf` +
    `&gid=${sheetId}` +
    `&size=A4` +
    `&portrait=true` +
    `&fitw=true` +
    `&sheetnames=false` +
    `&printtitle=false` +
    `&pagenumbers=false` +
    `&gridlines=false` +
    `&fzr=false` +
    `&top_margin=0.50` +
    `&bottom_margin=0.50` +
    `&left_margin=0.50` +
    `&right_margin=0.50`;

  const response = UrlFetchApp.fetch(url, {
    headers: {
      Authorization: `Bearer ${ScriptApp.getOAuthToken()}`
    },
    muteHttpExceptions: true,
  });

  const code = response.getResponseCode();
  if (code !== 200) {
    throw new Error(`PDF export failed. HTTP ${code}: ${response.getContentText()}`);
  }

  return response.getBlob().setName(filename);
}
```

## How To Use

1. Open the spreadsheet in Google Sheets.
2. Go to `Extensions > Apps Script`.
3. Paste the code into the script editor.
4. Replace `YOUR_FOLDER_ID` with the target Google Drive folder ID.
5. Save the project.
6. Run `exportQuotationPdf('SO-1001')` to test one order.
7. Run `exportAllQuotations()` to export every row in `ship_orders`.

## Required Workbook Setup

Your spreadsheet should have:

- `ship_orders`
- `ship_order_template`
- `template_control`

And:

- `template_control!B1` must contain the selected `Order Number`
- `ship_order_template` must use formulas that pull data based on `template_control!B1`

## Notes

- `SpreadsheetApp.flush()` is required so formula results update before export.
- `Utilities.sleep(1500)` gives Google Sheets a short delay to finish recalculation.
- The export uses the template sheet's `gid`, so only that sheet is printed to PDF.
- You can adjust PDF settings like paper size, portrait/landscape, and margins in the export URL.

## Optional Improvements

You can extend this by adding:

- a custom menu like `Quotation > Export Current`
- a PDF link column back in `ship_orders`
- file naming with dates or customer names
- automatic email sending after PDF creation

## Reference

- Google sample: https://developers.google.com/apps-script/samples/automations/generate-pdfs
- UrlFetchApp reference: https://developers.google.com/apps-script/reference/url-fetch/url-fetch-app
