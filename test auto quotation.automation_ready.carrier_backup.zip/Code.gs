const TEMPLATE_SHEET = 'ship_order_template';
const SOURCE_SHEET = 'ship_orders';
const CONTROL_SHEET = 'template_control';
const PDF_FOLDER_ID = '1SebVK4dC-yQrrCIHgELINNLltqztVLGK';
const PRINT_RANGE = 'A1:N26';

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Quotation Tools')
    .addItem('Open Ship Orders Manager', 'showShipOrdersSidebar')
    .addItem('Open Ship Orders Manager Dialog', 'showShipOrdersDialog')
    .addItem('Open Work Instructions', 'showWorkInstructionsSidebar')
    .addItem('Open Work Instructions Dialog', 'showWorkInstructionsDialog')
    .addItem('Export Template PDF', 'exportTemplatePdf')
    .addToUi();
}

function showShipOrdersSidebar() {
  const html = HtmlService.createHtmlOutputFromFile('ShipOrdersSidebar')
    .setTitle('Ship Orders Manager');
  SpreadsheetApp.getUi().showSidebar(html);
}

function showShipOrdersDialog() {
  const html = HtmlService.createHtmlOutputFromFile('ShipOrdersSidebar')
    .setWidth(920)
    .setHeight(820);
  SpreadsheetApp.getUi().showModalDialog(html, 'Ship Orders Manager');
}

function showWorkInstructionsSidebar() {
  const html = HtmlService.createHtmlOutputFromFile('WorkInstructions')
    .setTitle('Work Instructions');
  SpreadsheetApp.getUi().showSidebar(html);
}

function showWorkInstructionsDialog() {
  const html = HtmlService.createHtmlOutputFromFile('WorkInstructions')
    .setWidth(720)
    .setHeight(820);
  SpreadsheetApp.getUi().showModalDialog(html, 'Work Instructions');
}

function getShipOrdersData() {
  const sheet = getShipOrdersSheet_();
  const values = sheet.getDataRange().getValues();
  if (!values.length) {
    return { headers: [], rows: [] };
  }

  const headers = values[0];
  const rows = values.slice(1).map((row, index) => ({
    rowNumber: index + 2,
    orderNumber: stringifyValue_(row[0]),
    values: headers.reduce((acc, header, headerIndex) => {
      acc[header] = normalizeCellValue_(row[headerIndex], header);
      return acc;
    }, {}),
  }));

  return { headers, rows, activeOrderNumber: getActiveOrderNumber_() };
}

function getShipOrder(rowNumber) {
  const sheet = getShipOrdersSheet_();
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const row = sheet.getRange(rowNumber, 1, 1, headers.length).getValues()[0];

  return {
    rowNumber,
    values: headers.reduce((acc, header, index) => {
      acc[header] = normalizeCellValue_(row[index], header);
      return acc;
    }, {}),
  };
}

function loadShipOrderForEditor(rowNumber) {
  const record = getShipOrder(rowNumber);
  const sync = syncTemplateFromRow(rowNumber);
  return {
    rowNumber: record.rowNumber,
    values: record.values,
    activeOrderNumber: sync.activeOrderNumber,
  };
}

function saveShipOrder(record) {
  const sheet = getShipOrdersSheet_();
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const targetRow = record.rowNumber || sheet.getLastRow() + 1;
  const output = headers.map((header) => parseIncomingValue_(record.values[header], header));

  sheet.getRange(targetRow, 1, 1, output.length).setValues([output]);
  SpreadsheetApp.flush();
  return getShipOrder(targetRow);
}

function deleteShipOrder(rowNumber) {
  const sheet = getShipOrdersSheet_();
  if (rowNumber <= 1 || rowNumber > sheet.getLastRow()) {
    throw new Error('Invalid row number.');
  }
  sheet.deleteRow(rowNumber);
  SpreadsheetApp.flush();
  return getShipOrdersData();
}

function setActiveOrderNumber(orderNumber) {
  const sheet = getControlSheet_();
  sheet.getRange('B1').setValue(orderNumber || '');
  SpreadsheetApp.flush();
  return {
    activeOrderNumber: orderNumber || '',
  };
}

function syncTemplateFromRow(rowNumber) {
  const sheet = getShipOrdersSheet_();
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const orderIndex = headers.indexOf('Order Number');
  if (orderIndex === -1) {
    throw new Error('Order Number column not found.');
  }
  const orderNumber = stringifyValue_(sheet.getRange(rowNumber, orderIndex + 1).getValue());
  if (!orderNumber) {
    throw new Error(`Row ${rowNumber} does not contain an Order Number.`);
  }
  return setActiveOrderNumber(orderNumber);
}

function getActiveOrderNumber() {
  return {
    activeOrderNumber: getActiveOrderNumber_(),
  };
}

function exportTemplatePdf() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(TEMPLATE_SHEET);
  const folder = DriveApp.getFolderById(PDF_FOLDER_ID);
  const fileName = `${TEMPLATE_SHEET}.pdf`;

  const blob = exportSheetRangeAsPdf_(ss.getId(), sheet, PRINT_RANGE, fileName);
  const file = folder.createFile(blob);

  SpreadsheetApp.getUi().alert(`PDF created:\n${file.getName()}\n${file.getUrl()}`);

  return {
    fileId: file.getId(),
    url: file.getUrl(),
    name: file.getName(),
  };
}

function exportSheetRangeAsPdf_(spreadsheetId, sheet, a1Range, fileName) {
  const range = sheet.getRange(a1Range);
  const startRow = range.getRow() - 1;
  const endRow = range.getLastRow() - 1;
  const startCol = range.getColumn() - 1;
  const endCol = range.getLastColumn() - 1;

  const url =
    `https://docs.google.com/spreadsheets/d/${spreadsheetId}/export` +
    `?format=pdf` +
    `&gid=${sheet.getSheetId()}` +
    `&range=${encodeURIComponent(a1Range)}` +
    `&r1=${startRow}` +
    `&c1=${startCol}` +
    `&r2=${endRow}` +
    `&c2=${endCol}` +
    `&size=A4` +
    `&portrait=true` +
    `&fitw=true` +
    `&sheetnames=false` +
    `&printtitle=false` +
    `&pagenumbers=false` +
    `&gridlines=false` +
    `&fzr=false` +
    `&top_margin=0.50` +
    `&bottom_margin=0.50` +
    `&left_margin=0.50` +
    `&right_margin=0.50`;

  const response = UrlFetchApp.fetch(url, {
    headers: {
      Authorization: `Bearer ${ScriptApp.getOAuthToken()}`,
    },
    muteHttpExceptions: true,
  });

  if (response.getResponseCode() !== 200) {
    throw new Error(`PDF export failed. HTTP ${response.getResponseCode()}: ${response.getContentText()}`);
  }

  return response.getBlob().setName(fileName);
}

function getShipOrdersSheet_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SOURCE_SHEET);
  if (!sheet) {
    throw new Error(`Sheet not found: ${SOURCE_SHEET}`);
  }
  return sheet;
}

function getControlSheet_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONTROL_SHEET);
  if (!sheet) {
    throw new Error(`Sheet not found: ${CONTROL_SHEET}`);
  }
  return sheet;
}

function getActiveOrderNumber_() {
  return stringifyValue_(getControlSheet_().getRange('B1').getValue());
}

function normalizeCellValue_(value, header) {
  if (value instanceof Date) {
    return Utilities.formatDate(value, Session.getScriptTimeZone(), 'yyyy-MM-dd');
  }
  if (typeof value === 'number' && /zip code/i.test(header)) {
    return String(Math.trunc(value));
  }
  return stringifyValue_(value);
}

function stringifyValue_(value) {
  if (value === null || value === '') {
    return '';
  }
  return String(value);
}

function parseIncomingValue_(value, header) {
  if (value === '' || value === null || typeof value === 'undefined') {
    return '';
  }

  if (/date/i.test(header)) {
    return new Date(value);
  }

  if (/zip code/i.test(header)) {
    return String(value).trim();
  }

  if (isNumericHeader_(header)) {
    const parsed = Number(value);
    return Number.isNaN(parsed) ? value : parsed;
  }

  return value;
}

function isNumericHeader_(header) {
  return /(quantity|unit price|total|subtotal|tax|shipping|grand total)$/i.test(header);
}
