# Review of `dims&specs`

This note summarizes what the `dims&specs` sheet appears to do in `test auto quotation.xlsx`.

## What It Is

The `dims&specs` sheet looks like a packaging and freight lookup table, not a transaction sheet.

Its main purpose appears to be:

- determine how many pallets are needed for a shipment
- determine total panels and columns
- define pallet dimensions
- estimate shipment weight
- split a total wall count across pallet slots `#1` to `#8`

## Main Structure

The main lookup key is `Walls` in column `A`.

For each wall quantity, the sheet provides:

- `Pallets` in column `B`
- `Panels` in column `C`
- `Columns` in column `D`
- pallet dimensions and total freight measures in columns `E:H`
- pallet-by-pallet load splits in columns `I:AF`

### Interpreted Columns

- `A`: total number of walls
- `B`: number of pallets required
- `C`: total panels
- `D`: total columns
- `E`: length in inches
- `F`: width in inches
- `G`: height
- `H`: weight in pounds

Note:

- The header says `Height (lbs)`, which appears incorrect.
- Based on the values and formulas, this should likely be `Height (in)`.

## Product Math

The core product math is consistent:

- `Panels = Walls * 2`
- `Columns = Walls * 2`

This implies one wall assembly uses:

- 2 panels
- 2 columns

## Shipping Logic

### Small Orders

For `1` to `6` walls:

- column `B` says `small parcel`
- dimensions are mostly `44 x 44`
- weights are simple fixed increments

This suggests these quantities do not use standard pallet freight logic.

### Palletized Orders

From `7` walls onward:

- palletization begins
- most pallet footprints are `48 x 43`
- pallet count increases as wall count grows

Examples:

- `7` to `35` walls generally use `1` pallet
- `36` to `70` walls use `2` pallets
- `71` to `105` walls use `3` pallets
- `106` to `130` walls use `4` pallets
- `145`, `150`, `155` use `5` pallets
- `200` uses `6` pallets
- `250` uses `8` pallets

There are gaps in the sequence, so not every wall quantity has a defined row.

## Pallet Split Layout

The pallet blocks in columns `I:AF` define how the total wall quantity is distributed.

Each pallet has 3 fields:

- `Walls`
- `Panels`
- `Columns`

From a warehouse operations perspective, columns `I` onward are essentially the pallet loading instructions.

They show:

- how many walls go on each pallet
- how many panels are stacked on each pallet
- how many columns are stacked on each pallet

This means the section from `I` onward is not only for freight math. It also tells the warehouse how the shipment should be physically broken down pallet by pallet.

In practice, this can be used as:

- a pallet build guide
- a loading/distribution reference
- a way to explain how the total shipment is stacked across multiple pallets

Examples:

- `36` walls is split across 2 pallets as roughly `18 + 18`
- `71` walls is split across 3 pallets as `24 + 24 + 23`
- `106` walls is split across 4 pallets
- `250` walls is split across 8 pallets

This means the sheet is acting as a predefined load distribution table, not just a calculator.

## Example Summary Output

One likely use of `dims&specs` is to populate the shipment summary section in the template, for example:

| Total Units | Total Pallet Count | Total Weight | Notes |
| --- | --- | --- | --- |
| 336 | 3 | 1,726.6 | 84 walls (168 columns + 168 panels) |

### How to read this example

- `Total Units = 336`
  - this is the combined count of all shippable pieces
  - in this example: `168 columns + 168 panels = 336 units`
- `Total Pallet Count = 3`
  - the shipment is split across 3 pallets
  - the exact stack/distribution per pallet would come from columns `I` onward
- `Total Weight = 1,726.6`
  - this is the estimated total shipment weight from the lookup/formula logic
- `Notes = 84 walls (168 columns + 168 panels)`
  - this is the human-readable shipment description
  - it explains what the total units actually represent

### Why this matters

This is the bridge between `dims&specs` and the quotation/shipping template.

The left side of the sheet gives you the overall shipment totals:

- total units
- pallet count
- weight

The right side of the sheet, from `I` onward, explains how those totals are distributed pallet by pallet for warehouse execution.

## Formula Behavior

The formulas indicate:

- pallet height is derived from the pallet’s panel and column counts
- weight is derived from panel and column counts plus constants for steel/base pallet/dunnage

Example formula pattern:

- height: `((Panels + Columns) * 0.5) + 0.25 + 6`
- weight: `(Panels * 4.999) + (Columns * 4.341) + 2.5 + 50`

This suggests:

- panels and columns have different per-unit weights
- there is a base packaging/pallet weight included

## Special Cases at the Bottom

There are special rows for door-related shipments:

- `5 Doors no door shipped`
- `5 Doors doors shipped`

These are separate from the main wall lookup and appear to define:

- custom dimensions
- custom weight components
- custom freight breakdown

These rows look like one-off cargo spec templates rather than part of the main wall lookup sequence.

## What This Means for Automation

This sheet appears to be the missing freight-calculation source for:

- total pallet count
- total shipment weight
- pallet-by-pallet cargo specs
- template cargo specification rows

At the moment, `ship_orders` does not appear to contain a direct lookup key such as:

- `Wall Count`
- `ARW Wall Quantity`
- `Total Walls`

Without that, the automation cannot reliably use `dims&specs`.

## Risks / Gaps

The current design has a few issues:

- the sheet is not normalized
- lookup rows and special-case sections are mixed together
- some quantities are missing from the lookup range
- the `Height (lbs)` label is likely wrong
- there is no obvious direct link from `ship_orders` into this lookup

## Bottom Line

`dims&specs` appears to be the freight and packaging rules engine for American Range Wall shipments.

It is intended to answer:

- how many pallets are needed
- how much the shipment weighs
- how the load is split across pallets
- what cargo specs should appear in the shipping template

To use it properly in automation, the source data in `ship_orders` should include a clean field such as:

- `ARW Wall Count`

Once that exists, the automation can look up:

- pallet count
- total weight
- pallet splits
- cargo spec detail lines for the template
